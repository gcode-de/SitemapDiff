package de.samuelgesang.backend.crawls;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "crawls")
public record Crawl(
        @Id String _id,
        String siteId,
        String cronId,
        String finishedAt,
        String prevCrawlId,
        CrawlDiffItem[] crawlData
) {
}
