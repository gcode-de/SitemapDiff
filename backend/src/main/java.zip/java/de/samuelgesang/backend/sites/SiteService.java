package de.samuelgesang.backend.sites;

import de.samuelgesang.backend.crawls.Crawl;
import de.samuelgesang.backend.crawls.CrawlRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class SiteService {

    @Autowired
    private SiteRepository siteRepository;

    @Autowired
    private CrawlRepository crawlRepository;

    public List<Site> getAllSites() {
        List<Site> sites = siteRepository.findAll();
        return populateCrawls(sites);
    }

    public Optional<Site> getSiteById(String id) {
        Optional<Site> site = siteRepository.findById(id);
        return site.map(this::populateCrawls);
    }

    public List<Site> getSitesByUserId(String userId) {
        List<Site> sites = siteRepository.findByUserId(userId);
        return populateCrawls(sites);
    }

    public Site createSite(Site site) {
        return siteRepository.save(site);
    }

    public Site updateSite(String id, Site site) {
        return siteRepository.save(new Site(id, site.getUserId(), site.getName(), site.getBaseURL(), site.getSitemaps(), site.getCrawlIds()));
    }

    public void deleteSite(String id) {
        siteRepository.deleteById(id);
    }

    private List<Site> populateCrawls(List<Site> sites) {
        return sites.stream().map(this::populateCrawls).collect(Collectors.toList());
    }

    private Site populateCrawls(Site site) {
        List<Crawl> crawls = site.getCrawlIds().stream()
                .map(crawlRepository::findById)
                .filter(Optional::isPresent)
                .map(Optional::get)
                .collect(Collectors.toList());
        site.setCrawls(crawls);
        return site;
    }
}
