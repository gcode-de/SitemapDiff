package de.samuelgesang.backend.config;

import de.samuelgesang.backend.crawls.Crawl;
import de.samuelgesang.backend.crawls.CrawlDiffItem;
import org.bson.Document;
import org.springframework.core.convert.converter.Converter;

public class CrawlReadConverter implements Converter<Document, Crawl> {
    @Override
    public Crawl convert(Document source) {
        return new Crawl(
                source.getString("_id"),
                source.getString("siteId"),
                source.getString("cronId"),
                source.getString("finishedAt"),
                source.getString("prevCrawlId"),
                source.getList("crawlData", Document.class).stream()
                        .map(doc -> new CrawlDiffItem(doc.getString("action"), doc.getString("url"), doc.getBoolean("checked")))
                        .toArray(CrawlDiffItem[]::new)
        );
    }
}
