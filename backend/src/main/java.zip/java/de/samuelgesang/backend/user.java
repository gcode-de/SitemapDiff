package de.samuelgesang.backend;

public class user {
}
