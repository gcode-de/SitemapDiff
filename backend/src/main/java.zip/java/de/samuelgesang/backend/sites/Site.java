package de.samuelgesang.backend.sites;

import de.samuelgesang.backend.crawls.Crawl;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import java.util.List;

@Document(collection = "sites")
public class Site {

    private final String userId;
    private final String name;
    private final String baseURL;
    private final String[] sitemaps;
    private final List<String> crawlIds;
    @Id
    private String id;
    private List<Crawl> crawls;

    // Constructor
    public Site(String id, String userId, String name, String baseURL, String[] sitemaps, List<String> crawlIds) {
        this.id = id;
        this.userId = userId;
        this.name = name;
        this.baseURL = baseURL;
        this.sitemaps = sitemaps;
        this.crawlIds = crawlIds;
    }

    // Getters and Setters
    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getUserId() {
        return userId;
    }

    public String getName() {
        return name;
    }

    public String getBaseURL() {
        return baseURL;
    }

    public String[] getSitemaps() {
        return sitemaps;
    }

    public List<String> getCrawlIds() {
        return crawlIds;
    }

    public List<Crawl> getCrawls() {
        return crawls;
    }

    public void setCrawls(List<Crawl> crawls) {
        this.crawls = crawls;
    }
}
