package de.samuelgesang.backend.crawls;

import org.springframework.data.mongodb.repository.MongoRepository;

public interface CrawlRepository extends MongoRepository<Crawl, String> {
}
