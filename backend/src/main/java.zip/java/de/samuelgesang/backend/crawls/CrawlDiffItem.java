package de.samuelgesang.backend.crawls;

public record CrawlDiffItem(
        String action,
        String url,
        Boolean checked
) {
}
